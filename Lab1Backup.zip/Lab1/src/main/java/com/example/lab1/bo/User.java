package com.example.lab1.bo;

public class User
{
    private int Id;
    private String name;
    private String password;
    private Boolean isAdmin;


}
